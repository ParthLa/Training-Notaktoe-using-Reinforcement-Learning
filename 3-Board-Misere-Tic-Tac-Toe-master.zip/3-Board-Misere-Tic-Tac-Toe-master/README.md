# 3-Board-Misere-Tic-Tac-Toe
This is a 3-Board Misere Tic-Tac-Toe game. And AI will always win. Have a try?
