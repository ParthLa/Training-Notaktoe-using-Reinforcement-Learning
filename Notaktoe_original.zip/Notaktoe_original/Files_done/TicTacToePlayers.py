import numpy as np
from pdb import set_trace

"""
Random and Human-ineracting players for the game of TicTacToe.

Author: Evgeny Tyurin, github.com/evg-tyurin
Date: Jan 5, 2018.

Based on the OthelloPlayers by Surag Nair.

"""
class RandomPlayer():
    def __init__(self, game):
        self.game = game

    def play(self, board):
        a = np.random.randint(self.game.getActionSize())
        valids = self.game.getValidMoves(board, 1)
        while valids[a]!=1:
            a = np.random.randint(self.game.getActionSize())
        return a

class GreedyRandomPlayer():
    def __init__(self, game):
        self.game = game

    def play(self, board):
        valids = self.game.getFilteredValidMoves(board, 1)
        if valids[-1]==1: # if there is no valid moves(only suicide moves)
            valids = self.game.getValidMoves(board, 1)
            a = np.random.choice([i for i,n in enumerate(valids) if n ==1])
            return a
        
        else:
            a = np.random.choice([i for i,n in enumerate(valids) if n ==1])
            return a

class HumanTicTacToePlayer():
    def __init__(self, game):
        self.game = game

    def play(self, board):
        # display(board)
        valid = self.game.getValidMoves(board, 1)
        for i in range(len(valid)):
            if valid[i]:
                print(int(i/self.game.n), int(i%self.game.n))
        while True: 
            # Python 3.x
            a = input()
            # Python 2.x 
            # a = raw_input()
            x,y = [int(x) for x in a.split(' ')]
            a = self.game.n * x + y if x!= -1 else self.game.n ** 2
            if valid[a]:
                break
            else:
                print('Invalid')

        return a

class KnightTicTacToePlayer():
    def __init__(self, game):
        self.game = game

    def play(self, board):
        if self.game.last_move is None: # this is the first move
            a = int(self.game.n/2)*self.game.n + int(self.game.n/2)
            return a
        else:
            # get all valid knight moves (suicide moves filtered)
            valids = self.game.getValidKnightMoves(board, self.game.last_move)
            #print('valid_first', valids)
            if valids[-1]==1: # if there is no valid knight moves
                # get all other valid moves (suicide moves filtered)
                valids = self.game.getFilteredValidMoves(board, 1)
                if valids[-1]==1: # if there is no valid moves(only suicide moves)
                    valids = self.game.getValidMoves(board, 1)
                    a = np.random.choice([i for i,n in enumerate(valids) if n ==1])
                    return a
                
                else:
                    a = np.random.choice([i for i,n in enumerate(valids) if n ==1])
                    return a

            else:
                #print(valids)
                #set_trace()
                # randomly choose the index of valid move(v==1) in the valid vector
                #v = np.random.choice(len([v for v in valids if v==1]))
                a = np.random.choice([i for i,n in enumerate(valids) if n ==1])
                #a = self.game.n * x + y if x!= -1 else self.game.n ** 2

                return a

class BFKnightTicTacToePlayer(): # what is BF here?
    '''
    same as KnightTicTacToePlayer but return a list of valid moves instead of a random valid knight move
    '''
    def __init__(self, game):
        self.game = game

    def play(self, board):
        if self.game.last_move is None: # this is the first move
            a = int(self.game.n/2)*self.game.n + int(self.game.n/2)
            return a
        else:
            # get all valid knight moves (suicide moves filtered)
            valids = self.game.getValidKnightMoves(board, self.game.last_move)
            #print('valid_first', valids)
            if valids[-1]==1: # if there is no valid knight moves
                # get all other valid moves (suicide moves filtered)
                valids = self.game.getFilteredValidMoves(board, 1)
                if valids[-1]==1: # if there is no valid moves(only suicide moves)
                    valids = self.game.getValidMoves(board, 1)
                    #a = np.random.choice([i for i,n in enumerate(valids) if n ==1])
                    return [i for i,n in enumerate(valids) if n ==1]
                
                else:
                    #a = np.random.choice([i for i,n in enumerate(valids) if n ==1])
                    return [i for i,n in enumerate(valids) if n ==1]

            else:
                #print(valids)
                #set_trace()
                # randomly choose the index of valid move(v==1) in the valid vector
                #v = np.random.choice(len([v for v in valids if v==1]))
                #a = np.random.choice([i for i,n in enumerate(valids) if n ==1])
                #a = self.game.n * x + y if x!= -1 else self.game.n ** 2

                return [i for i,n in enumerate(valids) if n ==1]
# done