from copy import deepcopy
'''
Board class for the game of TicTacToe.
Default board size is 3x3.
Board data:
  1=white(O), -1=black(X), 0=empty
  first dim is row , 2nd is column:
     pieces[0][0] is the top left square,
     pieces[2][0] is the bottom left square,
Squares are stored and manipulated as (x,y) tuples.

Author: Evgeny Tyurin, github.com/evg-tyurin
Date: Jan 5, 2018.

Based on the board for the game of Othello by Eric P. Nichols.

'''
# from bkcharts.attributes import color
class Board():

    # list of all 8 directions on the board, as (x,y) offsets
    __directions = [(1,1),(1,0),(1,-1),(0,-1),(-1,-1),(-1,0),(-1,1),(0,1)]

    def __init__(self, n=3):
        "Set up initial board configuration."

        self.n = n
        # Create the empty board array.
        self.pieces = [None]*self.n
        for i in range(self.n):
            self.pieces[i] = [0]*self.n
        self.last_move = None

    # add [][] indexer syntax to the Board
    def __getitem__(self, index): 
        return self.pieces[index]

    def get_legal_moves(self, color):
        """Returns all the legal moves for the given color.
        (1 for white, -1 for black)
        @param color not used and came from previous version.        
        """
        moves = set()  # stores the legal moves.

        # Get all the empty squares (color==0)
        for y in range(self.n):
            for x in range(self.n):
                if self[x][y]==0:
                    newmove = (x,y)
                    moves.add(newmove)
        return list(moves)
    
    def get_filtered_legal_moves(self, color):
        """Returns all the legal moves (except suicide moves) for the given color.
        (1 for white, -1 for black)
        @param color not used and came from previous version.        
        """
        moves = set()  # stores the legal moves.

        # Get all the empty squares (color==0)
        for y in range(self.n):
            for x in range(self.n):
                if self[x][y]==0:
                    newmove = (x,y)
                    moves.add(newmove)
        moves = self.filter_suicide_moves(list(moves))
        return list(moves)


    def get_legal_knight_moves(self, last_move):
        """Returns all the legal knight moves respect to the moves from last player.
        last_play is a pair of indexes (x,y)      
        """
        moves = set()  # stores the legal moves.
        x, y = last_move
        # Get all direction
        direction = [(1,2), (2,1), (-1,2), (2,-1), (1,-2), (-2,1), (-1,-2), (-2,-1)]
        moves = set()  # stores the legal moves.
        for d in direction:
            if 0 <= x+d[0] <self.n and 0 <= y+d[1] <self.n and self[x+d[0]][y+d[1]] ==0:
                newmove = (x+d[0], y+d[1])
                moves.add(newmove)
        moves = self.filter_suicide_moves(list(moves))
        return moves

    def filter_suicide_moves(self, moves):
        '''
        filter the knight moves so that suicide moves are not allowed.
        '''
        new_moves = []
        for m in moves:
            board =self.execute_move_outplace(m,1)
            if not self.is_win_outplace(board):
                new_moves.append(m)
        return new_moves
            



    def has_legal_moves(self):
        for y in range(self.n):
            for x in range(self.n):
                if self[x][y]==0:
                    return True
        return False
        # returns true if any of the square is empty so that a move can be played there.
    
    def has_legal_knight_moves(self, last_move):
        if len(get_legal_knight_moves(last_move))>0:
            return True
        return False
    
    def is_win(self, color):
        """Check whether the given player has collected a triplet in any direction; 
        @param color (1=white,-1=black)
        """
        win = self.n
        # check y-strips
        for y in range(self.n):
            count = 0
            for x in range(self.n):
                #if self[x][y]==color:
                if self[x][y]==1:
                    count += 1
            if count==win:
                return True
        # check x-strips
        for x in range(self.n):
            count = 0
            for y in range(self.n):
                #if self[x][y]==color:
                if self[x][y]==1:
                    count += 1
            if count==win:
                return True
        # check two diagonal strips
        count = 0
        for d in range(self.n):
            #if self[d][d]==color:
            if self[d][d]==1:
                count += 1
        if count==win:
            return True
        count = 0
        for d in range(self.n):
            #if self[d][self.n-d-1]==color:
            if self[d][self.n-d-1]==1:
                count += 1
        if count==win:
            return True
        
        return False

    def execute_move(self, move, color):
        """Perform the given move on the board; 
        color gives the color pf the piece to play (1=white,-1=black)
        """

        (x,y) = move

        # Add the piece to the empty square.
        assert self[x][y] == 0
        self[x][y] = color
        self.last_move = (x,y)

    def execute_move_outplace(self, move, color):
        """Perform the given move on the board with changing the actually board
        use only to filter the suicide moves
        color gives the color pf the piece to play (1=white,-1=black)
        """

        (x,y) = move
        board_copy = deepcopy(self) # changes made on board_copy don't affect the original self board
        # Add the piece to the empty square.
        assert board_copy[x][y] == 0
        board_copy[x][y] = color
        return board_copy
    
    def is_win_outplace(self, board):
        """Check whether the given player has collected a triplet in any direction; 
        @param color (1=white,-1=black)
        """
        win = self.n
        # check y-strips
        for y in range(self.n):
            count = 0
            for x in range(self.n):
                #if self[x][y]==color:
                if board[x][y]==1:
                    count += 1
            if count==win:
                return True
        # check x-strips
        for x in range(self.n):
            count = 0
            for y in range(self.n):
                #if self[x][y]==color:
                if board[x][y]==1:
                    count += 1
            if count==win:
                return True
        # check two diagonal strips
        count = 0
        for d in range(self.n):
            #if self[d][d]==color:
            if board[d][d]==1:
                count += 1
        if count==win:
            return True
        count = 0
        for d in range(self.n):
            #if self[d][self.n-d-1]==color:
            if board[d][self.n-d-1]==1:
                count += 1
        if count==win:
            return True
        
        return False
# done

