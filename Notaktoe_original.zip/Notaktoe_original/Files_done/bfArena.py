import numpy as np
from pytorch_classification.utils import Bar, AverageMeter
import timeit
from tictactoe.TicTacToeGame import TicTacToeGame
from pdb import set_trace
import pickle
import argparse

class Node():
    inst_count = 0
 
    def __init__(self,value):
        self.value = value
        self.win = 0
        self.parent = None
        self.children = []
        # Node.inst_count += 1

class Config():
    def __init__(self):
        self.parser = argparse.ArgumentParser(description='Options')

    def initialize(self):
        self.parser.add_argument(
            '--n', type=int, help='size of board nxn',
            default=5,
        )
        self.parser.add_argument(
            '--verbose', type=str, help='show board or not',
            default='True',
        )


        self.args = self.parser.parse_args()
        return self.args

class Arena():
    """
    An Arena class where any 2 agents can be pit against each other.
    """
    def __init__(self, game, display=None):
        """
        Input:
            game: Game object
        """
        self.game = game
        self.display = display
        self.states_dict = {} # a dictionary stores states, (byte_string board, set(actions))
        self.states_dict_save = {}
        self.states_dict_bf = {} # a dictionary stores bf players states
        self.current_path = [] # what exactly is this? - a set of nodes where each element of set is an action
    
    def query_dict(self, board, curPlayer):
        action = self.states_dict[board.tostring()].pop()
        board, curPlayer = self.game.getNextState(board, curPlayer, action.value)
        self.current_path.append(action)
        return board, curPlayer

    def roll_back(self, board, curPlayer):
        action = self.current_path.pop()
        x, y  = (int(action.value/self.game.n), action.value%self.game.n)
        board[x][y] = 0
        curPlayer = -curPlayer
        return board, curPlayer

    def check_board_variation(self,board):
        board_list = []
        for i in range(4):
            board_list.append(np.rot90(board,i).tostring())
            board_list.append(np.fliplr(np.rot90(board,i)).tostring())
        board_list.append(np.fliplr(board).tostring())
        #print([np.fromstring(b,int) for b in set(board_list)])
        board_set = set(board_list)
        board_set.remove(board.tostring())
        #print(board_set)
        return board_set

    def playGame(self, verbose=False):
        """
        Executes brute force.
        """
        #players = [self.player2, None, self.player1]
        curPlayer = 1
        board = self.game.getInitBoard()
        it = 0

        while True:
            #print(self.current_path)
            it+=1
            # if it >10000:
            #     break
            if it%10000==0:
                print(it) # this is printed irrespective of verbose
            if verbose:
                assert(self.display)
                print("Turn ", str(it), "Player ", str(curPlayer))
                self.display(board)
            if it ==1 and np.sum(board) ==0: # if the board is empty
                # put the piece in middle of the board
                if board.tostring() not in self.states_dict.keys():
                    self.states_dict[board.tostring()] = set()
                #set_trace()
                root = Node(int(self.game.n*self.game.n/2))
                self.states_dict[board.tostring()].add(root)
                # to ensure pop the same element each time(or not necessary?)
                self.states_dict[board.tostring()] = list(self.states_dict[board.tostring()])
                action = self.states_dict[board.tostring()].pop()
                board, curPlayer = self.game.getNextState(board, curPlayer, action.value) 
                self.current_path.append(action)
                continue
            # backtracking to the first move
            if np.sum(board)==0:
                print('end')
                # with open('./dict/states_{}_final.pickle'.format(self.game.n,it), 'wb') as handle:
                #     pickle.dump(self.states_dict, handle, protocol=pickle.HIGHEST_PROTOCOL)
                # with open('./dict/tree_{}_final.pickle'.format(self.game.n,it), 'wb') as treefile:
                #     pickle.dump(root, treefile, protocol=pickle.HIGHEST_PROTOCOL)
                with open('states{}.pickle'.format(self.game.n,it), 'wb') as handle:
                    pickle.dump(self.states_dict, handle, protocol=pickle.HIGHEST_PROTOCOL)
                with open('tree{}.pickle'.format(self.game.n,it), 'wb') as treefile:
                    pickle.dump(root, treefile, protocol=pickle.HIGHEST_PROTOCOL)    
                break
            if it%10e8 ==0:
                with open('./dict/states_{}.pickle'.format(self.game.n), 'wb') as handle:
                    pickle.dump(self.states_dict, handle, protocol=pickle.HIGHEST_PROTOCOL)
                with open('./dict/tree_{}.pickle'.format(self.game.n), 'wb') as treefile:
                    pickle.dump(root, treefile, protocol=pickle.HIGHEST_PROTOCOL)
            # first player is always knight move player 
            if curPlayer ==1:

                # if the board's variation has been explored
                if len([b for b in self.check_board_variation(board) if b in self.states_dict.keys()]) >0:
                    assert len([b for b in self.check_board_variation(board) if b in self.states_dict.keys()]) ==1
                    board, curPlayer = self.roll_back(board, curPlayer)
                    continue

                # if the board has already been explored
                if board.tostring() in self.states_dict.keys():
                    # if there are still actions(moves) not been explored
                    if self.states_dict[board.tostring()]: # the size of the set !=0 implies that all actions are not yet popped out
                        board, curPlayer = self.query_dict(board, curPlayer)
                        continue
                    else: # if all possible moves has been tried
                        # roll back one pieces (opponent's)
                        board, curPlayer = self.roll_back(board, curPlayer)
                        continue



                # get valids move
                valids = self.game.getValidKnightMoves(board, self.game.last_move)
                if valids[-1]==1: # if there exist no valid knight moves
                    # get all other valid moves (suicide moves filtered)
                    valids = self.game.getFilteredValidMoves(board, 1)
                    if valids[-1]==1: # if there is no valid moves(only suicide moves)
                        # roll back one pieces (opponent's)
                        valids = self.game.getValidMoves(board, 1)
                        actions = [i for i,n in enumerate(valids) if n ==1]
                        actions = [Node(action) for action in actions]
                        for node in actions:
                            node.parent = self.current_path[-1]
                            self.current_path[-1].children.append(node)



                        board, curPlayer = self.roll_back(board, curPlayer)
                        continue
                    
                    else:# if there exist valid moves(except knight moves and suicide moves)
                        actions =  [i for i,n in enumerate(valids) if n ==1]

                else:# if there exist valid knight moves
                    actions = [i for i,n in enumerate(valids) if n ==1]

                # update dict
                if board.tostring() not in self.states_dict.keys(): # this board position is not explored yet
                    self.states_dict[board.tostring()] = set()
                actions = [Node(action) for action in actions]
                self.states_dict[board.tostring()].update(actions)
                # to ensure pop the same element each time(or not necessary?)
                self.states_dict[board.tostring()] = list(self.states_dict[board.tostring()])
                action = self.states_dict[board.tostring()].pop() # a random element is popped off the set
                board, curPlayer = self.game.getNextState(board, curPlayer, action.value)
                action.parent = self.current_path[-1] # what does current_path[-1] symbolise here? current_path[n-1]
                self.current_path[-1].children.append(action)
                self.current_path.append(action) # what is current_path? done
                continue
                
            # second player is always greedy player -- should we assume this?
            elif curPlayer == -1:
                if len([b for b in self.check_board_variation(board) if b in self.states_dict.keys()]) >0:
                    assert len([b for b in self.check_board_variation(board) if b in self.states_dict.keys()]) ==1
                    board, curPlayer = self.roll_back(board, curPlayer)
                    continue
                
                # if the board has already been explored
                if board.tostring() in self.states_dict.keys():
                    # if there are still actions(moves) not been explored
                    if self.states_dict[board.tostring()]: # some actions present in the set mapped to this board position
                        action = self.states_dict[board.tostring()].pop()
                        board, curPlayer = self.game.getNextState(board, curPlayer, action.value)
                        action.parent = self.current_path[-1]
                        self.current_path[-1].children.append(action)
                        self.current_path.append(action) 
                        # (still to ask)
                        # why don't we use here self.query_dict |||ar to the one used for player=1 in line 137? 
                        # because this player is greedy and so chooses the best of the available action without thinking its future effects 
                        # self.current_path.append(action)
                        continue
                    else: # if all possible moves has been tried
                        # roll back one pieces (opponent's)
                        self.current_path[-1].win =1 # self.current_path[-1] == self.current_path[n-1] since we have => 0,1,...,n-1 == -n,-(n-1),...,-1 for indexing in python
                        # no available greedy action => the opponent has ,a kind of, filled the whole board, so the previous move of this player helped him win the game
                        # here, -1 is winning. So, why to set win to 1 ?
                        board, curPlayer = self.roll_back(board, curPlayer)
                        if self.current_path: # true if the set -- self.current_path is non_empty
                            self.game.last_move = (int(self.current_path[-1].value/self.game.n), self.current_path[-1].value%self.game.n)
                            # why are we splitting the current_path.value into 2 numbers --> (quotient,remainder) ?
                            # quotient - the row number and remainder - the column number
                        else:
                            self.game.last_move =None
                        continue

                # get valids move
                valids = self.game.getFilteredValidMoves(board, 1)
                if valids[-1]==1: # if there is no valid moves(only suicide moves) => condition specified in TicTacToeGame.py
                    valids = self.game.getValidMoves(board, 1)
                    actions = [i for i,n in enumerate(valids) if n ==1]
                    actions = [Node(action) for action in actions]
                    for node in actions:
                        node.parent = self.current_path[-1]
                        # making the present action , the parent of the future possible actions
                        # when the last player is -1 (meaning -1 is the loser of the game)
                        # set the node.win to 1
                        node.win =1
                        self.current_path[-1].children.append(node)
                    board, curPlayer = self.roll_back(board, curPlayer)
                    if self.current_path:
                        self.game.last_move = (int(self.current_path[-1].value/self.game.n), self.current_path[-1].value%self.game.n)
                    else:
                        self.game.last_move =None
                    #set_trace()
                    continue
                
                else:
                    actions =[i for i,n in enumerate(valids) if n ==1]
                    # enumerate (valids) returns pair<index,valids[index]> in this case with index starting from 0
                    # in general, enumerate(valids,counter) returns pair<counter,valids[i]> with i starting from 0 
                # update dict
                if board.tostring() not in self.states_dict.keys():
                    self.states_dict[board.tostring()] = set()
                actions = [Node(action) for action in actions]
                self.states_dict[board.tostring()].update(actions)
                # still to ask
                # to ensure pop the same element each time(or not necessary?) ?
                self.states_dict[board.tostring()] = list(self.states_dict[board.tostring()])
                action = self.states_dict[board.tostring()].pop()
                board, curPlayer = self.game.getNextState(board, curPlayer, action.value)
                action.parent = self.current_path[-1]
                self.current_path[-1].children.append(action)
                self.current_path.append(action)
                #self.current_path.append(action)
                continue

        
        return 

if __name__ == "__main__":
    #start = timeit.default_timer()
    config = Config().initialize()
    g = TicTacToeGame(config.n)
    # done till here -- proceed with arena
    if config.verbose == 'True':
        arena = Arena(g, display=g.display)
        arena.playGame(True)
    else:
        arena = Arena(g, display=g.display)
        arena.playGame(False)
    
# done    